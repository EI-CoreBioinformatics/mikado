Mikado.parsers package
======================

Submodules
----------

Mikado.parsers.GFF module
-------------------------

.. automodule:: Mikado.parsers.GFF
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.parsers.GTF module
-------------------------

.. automodule:: Mikado.parsers.GTF
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.parsers.bed12 module
---------------------------

.. automodule:: Mikado.parsers.bed12
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.parsers.blast_utils module
---------------------------------

.. automodule:: Mikado.parsers.blast_utils
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.parsers.blast_xml module
-------------------------------

.. automodule:: Mikado.parsers.blast_xml
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.parsers.gfannotation module
----------------------------------

.. automodule:: Mikado.parsers.gfannotation
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: Mikado.parsers
    :members:
    :undoc-members:
    :show-inheritance:
