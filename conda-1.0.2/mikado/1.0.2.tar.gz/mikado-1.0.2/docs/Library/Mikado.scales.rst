Mikado.scales package
=====================

Submodules
----------

Mikado.scales.accountant module
-------------------------------

.. automodule:: Mikado.scales.accountant
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.scales.assigner module
-----------------------------

.. automodule:: Mikado.scales.assigner
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.scales.class_codes module
--------------------------------

.. automodule:: Mikado.scales.class_codes
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.scales.compare module
----------------------------

.. automodule:: Mikado.scales.compare
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.scales.contrast module
-----------------------------

.. automodule:: Mikado.scales.contrast
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.scales.f1 module
-----------------------

.. automodule:: Mikado.scales.f1
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.scales.resultstorer module
---------------------------------

.. automodule:: Mikado.scales.resultstorer
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: Mikado.scales
    :members:
    :undoc-members:
    :show-inheritance:
