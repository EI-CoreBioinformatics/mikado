Mikado.subprograms.util package
===============================

Submodules
----------

Mikado.subprograms.util.awk_gtf module
--------------------------------------

.. automodule:: Mikado.subprograms.util.awk_gtf
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.subprograms.util.class_codes module
------------------------------------------

.. automodule:: Mikado.subprograms.util.class_codes
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.subprograms.util.convert module
--------------------------------------

.. automodule:: Mikado.subprograms.util.convert
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.subprograms.util.grep module
-----------------------------------

.. automodule:: Mikado.subprograms.util.grep
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.subprograms.util.merge_blast module
------------------------------------------

.. automodule:: Mikado.subprograms.util.merge_blast
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.subprograms.util.metrics module
--------------------------------------

.. automodule:: Mikado.subprograms.util.metrics
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.subprograms.util.stats module
------------------------------------

.. automodule:: Mikado.subprograms.util.stats
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.subprograms.util.trim module
-----------------------------------

.. automodule:: Mikado.subprograms.util.trim
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: Mikado.subprograms.util
    :members:
    :undoc-members:
    :show-inheritance:
