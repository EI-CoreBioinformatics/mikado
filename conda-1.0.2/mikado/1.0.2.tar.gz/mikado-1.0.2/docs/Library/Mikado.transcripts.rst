Mikado.transcripts package
==========================

Subpackages
-----------

.. toctree::

    Mikado.transcripts.transcript_methods

Submodules
----------

Mikado.transcripts.clique_methods module
----------------------------------------

.. automodule:: Mikado.transcripts.clique_methods
    :members:
    :undoc-members:
    :show-inheritance:

.. _transcript-class:

Mikado.transcripts.transcript module
------------------------------------

.. automodule:: Mikado.transcripts.transcript
    :members:
    :undoc-members:
    :show-inheritance:

Mikado.transcripts.transcriptchecker module
-------------------------------------------

.. automodule:: Mikado.transcripts.transcriptchecker
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: Mikado.transcripts
    :members:
    :undoc-members:
    :show-inheritance:
