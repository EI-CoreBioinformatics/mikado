# coding: utf-8

"""
    This module defines the transcript-like objects.
"""

from .transcript import Transcript
from .transcriptchecker import TranscriptChecker