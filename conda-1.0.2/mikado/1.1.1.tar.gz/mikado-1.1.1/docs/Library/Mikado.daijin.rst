Mikado.daijin package
=====================

Module contents
---------------

.. automodule:: Mikado.daijin
    :members:
    :undoc-members:
    :show-inheritance:
