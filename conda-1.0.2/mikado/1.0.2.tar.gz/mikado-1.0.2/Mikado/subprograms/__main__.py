"""This file is empty but it is necessary for the spawn multiprocessing
method to work appropriately."""


__author__ = 'Luca Venturini'
